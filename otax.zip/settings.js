
const settings = {
  OWNER_URL: "https://t.me/Otapengenkawin", //ganti Otapengenkawin dengan username tele lu
};
//ganti bagian dalam '...' saja
module.exports = settings;