const TelegramBot = require('node-telegram-bot-api');
const axios = require('axios');
const fs = require('fs');
const moment = require('moment');

const TELEGRAM_TOKEN = '8083479484:AAEIjHHjE9GyX8GqcIE6V6PDbaPEwls0Ysk';
const VERCEL_TOKEN = 'uHvtGKd0sGkFTtk8xJMlbBOo';
const ADMIN_LINK = 'https://t.me/iziiavliablez';

const bot = new TelegramBot(TELEGRAM_TOKEN, { polling: true });
const userState = {};

bot.onText(/\/start/, (msg) => {
  const welcome = `👋 <b>Selamat Datang di <i>Web Creator Bot</i></b>\n\n` +
                  `📁 Kirim file <b>.html</b> kamu,\n` +
                  `📝 Lalu kirim nama projectnya.\n\n` +
                  `📦 Bot ini akan otomatis membuat website <b>gratis</b> di Vercel!\n\n` +
                  `🚀 Ayo mulai sekarang!`;

  const keyboard = {
    reply_markup: {
      inline_keyboard: [
        [{ text: '👑 Admin', url: ADMIN_LINK }]
      ]
    },
    parse_mode: 'HTML'
  };

  bot.sendMessage(msg.chat.id, welcome, keyboard);
});

bot.on('document', async (msg) => {
  const chatId = msg.chat.id;
  const file = msg.document;

  if (!file.file_name.endsWith('.html')) {
    return bot.sendMessage(chatId, '❌ Hanya file .html yang didukung.');
  }

  try {
    const link = await bot.getFileLink(file.file_id);
    const htmlFile = await axios.get(link, { responseType: 'arraybuffer' });
    const path = `./${chatId}.html`;
    fs.writeFileSync(path, htmlFile.data);
    userState[chatId] = path;

    bot.sendMessage(chatId, '✅ File diterima!\n\n💬 Sekarang kirim <b>nama website</b> kamu (tanpa spasi).', { parse_mode: 'HTML' });
  } catch (err) {
    bot.sendMessage(chatId, '❌ Gagal mengunduh file.');
  }
});

bot.on('message', async (msg) => {
  const chatId = msg.chat.id;
  const filePath = userState[chatId];

  if (filePath && msg.text && !msg.text.startsWith('/')) {
    const name = msg.text.toLowerCase().replace(/\s+/g, '-');
    const html = fs.readFileSync(filePath).toString('base64');

    const payload = {
      name,
      files: [
        {
          file: 'index.html',
          data: html,
          encoding: 'base64'
        }
      ],
      projectSettings: {
        framework: null,
        devCommand: null,
        installCommand: null,
        buildCommand: null,
        outputDirectory: '.',
        rootDirectory: null
      }
    };

    try {
      await axios.post('https://api.vercel.com/v13/deployments', payload, {
        headers: {
          Authorization: `Bearer ${VERCEL_TOKEN}`,
          'Content-Type': 'application/json'
        }
      });

      const date = moment().format('DD MMMM YYYY, HH:mm');
      const reply = `✅ <b>Website berhasil dibuat!</b>\n\n` +
                    `📛 <b>Nama:</b> ${name}\n` +
                    `🔗 <b>Link:</b> https://${name}.vercel.app\n` +
                    `🗓️ <b>Dibuat:</b> ${date}`;

      bot.sendMessage(chatId, reply, { parse_mode: 'HTML' });
    } catch (err) {
      bot.sendMessage(chatId, `❌ Gagal upload ke Vercel:\n${JSON.stringify(err.response?.data || err.message)}`);
    } finally {
      fs.unlinkSync(filePath);
      delete userState[chatId];
    }
  }
});